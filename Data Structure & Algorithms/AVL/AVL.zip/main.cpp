# include "AVL.h"

int main() {
    AVL<int> avl{} ;

    avl.insert(9) ;
    avl.insert(5) ;
    avl.insert(10) ;
    avl.insert(0) ;
    avl.insert(6) ;
    avl.insert(11) ;
    avl.insert(-1) ;
    avl.insert(1) ;
    avl.insert(2) ;

    avl.preOrder() ;
    cout << '\n' ;

    avl.remove(10) ;

    avl.preOrder() ;
    cout << '\n' ;
    return 0;
}

/*
 *  9 1 0 -1 5 2 6 10 11
 *  1 0 -1 9 5 2 6 11
 *  
 */